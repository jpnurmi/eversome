function onLoadHandler(){

}
function log(string){
    document.body.innerHTML = "<pre>"+string+"</pre>"+document.body.innerHTML;
}

function handleResourceLoad(hash, guid, filename, fullPath){
    var divs = document.getElementsByTagName("en-media");
    if(divs === null){
        log("no resources");
    }else{
        for (var i = 0; i < divs.length; i++) {
            var div = divs[i];
            if(div.getAttribute("hash").toLowerCase() == hash.toLowerCase()){
                if(isImage(div)){
                    processImage(hash, guid, div, fullPath);
                }else{
                    processAttach(hash, guid, div, filename, fullPath);
                }
            }
        }
    }
}
function processImage(hash, guid, div, fullPath){
      div.innerHTML += "<img src='"+fullPath+"' />";
}
function processAttach(hash, guid, div, filename, fullPath){
      //div.innerHTML += "<a href='"+guid+"/"+guid+"'>"+filename+"</a>";
    div.innerHTML += "<a href='#' onclick=\"window.qml.openFile('"+fullPath+"');\" >"+filename+"</a>";

}
function isImage(div){
    return div.getAttribute("type").indexOf("image") != -1;
}
